from django.contrib import admin
from .models import AppliancesList
# Register your models here.

admin.site.register(AppliancesList)
