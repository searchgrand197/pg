

from django.urls import path
from . import views
urlpatterns = [
    path('',views.index,name="k"),
    path('login/',views.loginPage,name="login"),
    path('logout/', views.logoutUser, name="logout"),
    path('homePage/',views.homePage,name="homePage"),
    path('applianceStatus/',views.applianceStatus,name="applianceStatus"),


    # Edit and save info of user
    # path('editInfo', views.editInfo, name="editInfo"),
    path('saveInfo/', views.saveInfo, name="saveInfo"),
]
