

from django.urls import path
from . import views
urlpatterns = [
    path('',views.index,name="k"),
    path('login/',views.loginPage,name="login"),
    path('logout/', views.logoutUser, name="logout"),
    path('homePage/',views.homePage,name="homePage"),
    path('applianceStatus/',views.applianceStatus,name="applianceStatus"),
    path('handlerequest/', views.handlerequest, name = 'handlerequest'),

    # Wallet
    path('wallet/', views.wallet, name = 'wallet'),
    # Edit and save info of user
    # path('editInfo', views.editInfo, name="editInfo"),
    path('saveInfo/', views.saveInfo, name="saveInfo"),

    #payment url
    path("payment/<int:pk>", views.payment, name = "payment"),
    path('displaycart/', views.DisplayCart, name="displaycart"),


]
