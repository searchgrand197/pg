from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
# Create your models here.
import uuid
class AppliancesList(models.Model):
    payment_status_choices = (
        (1, 'SUCCESS'),
        (2, 'FAILURE' ),
        (3, 'PENDING'),
    )


    id = models.UUIDField(default=uuid.uuid4,primary_key=True,unique=True,editable=True)
    i_name = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    device_name = models.CharField(max_length=10, null=True)
    # device_password = models.CharField(max_length=10)
    # payment for razor pay
    total_amount = models.FloatField()
    payment_status = models.IntegerField(choices = payment_status_choices, default=3)
    order_id = models.CharField(unique=True, max_length=100, null=True, blank=True, default=None)
    datetime_of_payment = models.DateTimeField(default=timezone.now)
    razorpay_order_id = models.CharField(max_length=500, null=True, blank=True)
    razorpay_payment_id = models.CharField(max_length=500, null=True, blank=True)
    razorpay_signature = models.CharField(max_length=500, null=True, blank=True)

    # duration count
    rc_sta = models.DateField(auto_now=False)
    rc_exp = models.DateField(auto_now=False)
    duration = models.DurationField(null=True, blank=True)

    wifi_name = models.CharField(max_length=12,null=True,default='wifi')
    wifi_password = models.CharField(max_length=12,null=True,default='12345')
    emailId = models.EmailField(max_length=20,default='none@gmail.com',null=True)
    # serial_number

    # Bulb 1
    bulb1 = models.CharField(max_length=12,null=True,default='0')
    bulb1_status = models.IntegerField(null=True,default='0')
    
    bulb2 = models.CharField(max_length=12,null=True,default='0')
    bulb2_status = models.IntegerField(null=True,default='0')
    
    bulb3 = models.CharField(max_length=12,null=True,default='0')
    bulb3_status = models.IntegerField(null=True,default='0')
    
    bulb4 = models.CharField(max_length=12,null=True,default='0')
    bulb4_status = models.IntegerField(null=True,default='0')
    
    # Socket 2
    switch1 = models.CharField(max_length=12,null=True,default='0')
    switch1_status = models.IntegerField(null=True,default='0')
    
    switch2 = models.CharField(max_length=12,null=True,default='0')
    switch2_status = models.IntegerField(null=True,default='0')

    switch3 = models.CharField(max_length=12,null=True,default='0')
    switch3_status = models.IntegerField(null=True,default='0')
    
    switch4 = models.CharField(max_length=12,null=True,default='0')
    switch4_status = models.IntegerField(null=True,default='0')

    # # Section 3
    cooler = models.CharField(max_length=12,null=True,default='0')
    cooler_status = models.IntegerField(null=True,default='0')

    freeze = models.CharField(max_length=12,null=True,default='0')
    freeze_status = models.IntegerField(null=True,default='0')

    ac = models.CharField(max_length=12,null=True,default='0')
    ac_status = models.IntegerField(null=True,default='0')

    # # Section 4
    fan = models.CharField(max_length=12,null=True,default='0')
    fan_status = models.IntegerField(null=True,default='0')

    def save(self, *args, **kwargs):
        if self.order_id is None and self.datetime_of_payment and self.id:
            self.order_id = str('PAY')+str(self.id)
            super().save(*args, **kwargs)
        self.duration = self.rc_exp - self.rc_sta
        return super(AppliancesList, self).save(*args, **kwargs)