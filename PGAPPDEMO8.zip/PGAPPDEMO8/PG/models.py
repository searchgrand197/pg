from django.db import models
from django.contrib.auth.models import User

# Create your models here.
import uuid
class AppliancesList(models.Model):
    id = models.UUIDField(default=uuid.uuid4,primary_key=True,unique=True,editable=True)
    i_name = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    device_name = models.CharField(max_length=10, null=True)
    # device_password = models.CharField(max_length=10)
    wifi_name = models.CharField(max_length=12,null=True,default='wifi')
    wifi_password = models.CharField(max_length=12,null=True,default='12345')
    emailId = models.EmailField(max_length=20,default='none@gmail.com',null=True)
    # serial_number

    # Bulb 1
    bulb1 = models.CharField(max_length=12,null=True)
    bulb1_status = models.IntegerField(null=True)
    
    bulb2 = models.CharField(max_length=12,null=True)
    bulb2_status = models.IntegerField(null=True)
    
    bulb3 = models.CharField(max_length=12,null=True)
    bulb3_status = models.IntegerField(null=True)
    
    bulb4 = models.CharField(max_length=12,null=True)
    bulb4_status = models.IntegerField(null=True)
    
    # Socket 2
    switch1 = models.CharField(max_length=12,null=True)
    switch1_status = models.IntegerField(null=True)
    
    switch2 = models.CharField(max_length=12,null=True)
    switch2_status = models.IntegerField(null=True)

    switch3 = models.CharField(max_length=12,null=True)
    switch3_status = models.IntegerField(null=True)
    
    switch4 = models.CharField(max_length=12,null=True)
    switch4_status = models.IntegerField(null=True)

    # # Section 3
    cooler = models.CharField(max_length=12,null=True)
    cooler_status = models.IntegerField(null=True)

    freeze = models.CharField(max_length=12,null=True)
    freeze_status = models.IntegerField(null=True)

    ac = models.CharField(max_length=12,null=True)
    ac_status = models.IntegerField(null=True)

    # # Section 4
    fan = models.CharField(max_length=12,null=True)
    fan_status = models.IntegerField(null=True)