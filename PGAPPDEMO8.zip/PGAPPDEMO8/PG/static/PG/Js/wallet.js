// Wallet Modal
// var hamBtn = document.getElementById("hamBtn")
// var myWallet = document.getElementById("myWallet")
// var closeWallet = document.getElementById("closeWallet")
// var overlaymyWallet = document.getElementById("overlayMyWallet")
var rechargeButton = document.getElementById("rechargeButton")
var packs = document.getElementById("packs")


    // hamBtn.addEventListener("click",function editModal(){
    
    //     myWallet.style.display = "flex"
    //     overlaymyWallet.style.display = "block"
        
    // })
    // closeWallet.addEventListener("click",function close(){
    //     myWallet.style.display="none"
    //     overlaymyWallet.style.display="none"
    // })


rechargeButton.addEventListener("click",function(){
    if(packs.style.display == "none"){
        packs.style.display="flex"
    }else{
        packs.style.display="none"
    }
})