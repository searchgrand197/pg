
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import AppliancesList
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
import boto3
import json
# paste aws here

dynamodb = client.resource('dynamodb')

table = dynamodb.Table('PGDashboard')
# Index function, Rendering the main page
@login_required(login_url='login')
def index(request):
    list_to_html = AppliancesList.objects.get(i_name=request.user)
    # print(list_to_html)
    # print(list_to_html.bulb1_status)
    # print(list_to_html.switch1_status)
    return render(request,'PG/index.html',{'list':list_to_html})



# Login
def loginPage(request):
    if request.user.is_authenticated:
        return redirect('k')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password =request.POST.get('password')
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('k')
            else:
                messages.info(request, 'Username OR password is incorrect')

        context = {}
        return render(request, 'PG/login.html', context)


# Logout
@login_required(login_url = 'login')
def logoutUser(request):
    logout(request)
    return redirect('login')


# Getting data from backend using ajax through homePage function
@login_required(login_url='login')
def homePage(request):
    list_data = AppliancesList.objects.get(i_name=request.user)
    sid =  list_data.id
    aws_id = str(sid)
    resp = table.get_item(
        Key={
            'id' : aws_id,
        }
    )
    list_data.bulb1_status = resp['Item'].get('bulb1')
    list_data.bulb2_status = resp['Item'].get('bulb2')
    list_data.bulb3_status = resp['Item'].get('bulb3')
    list_data.bulb4_status = resp['Item'].get('bulb4')
    # Socket
    list_data.switch1_status = resp['Item'].get('switch1')
    list_data.switch2_status = resp['Item'].get('switch2')
    list_data.switch3_status = resp['Item'].get('switch3')
    list_data.switch4_status = resp['Item'].get('switch4')
    # Heavy Appliances
    list_data.cooler_status = resp['Item'].get('cooler')
    list_data.freeze_status = resp['Item'].get('freeze')
    list_data.ac_status = resp['Item'].get('ac')
    list_data.fan_status = resp['Item'].get('fan')
    list_data.save()


    try:
        list_data = AppliancesList.objects.get(i_name=request.user)
        p = {

            'id':list_data.id,
            'bulb1':list_data.bulb1_status,
            'bulb2':list_data.bulb2_status,
            'bulb3':list_data.bulb3_status,
            'bulb4':list_data.bulb4_status,
            'socket1':list_data.switch1_status,
            'socket2':list_data.switch2_status,
            'socket3':list_data.switch3_status,
            'socket4':list_data.switch4_status,
            'cooler':list_data.cooler_status,
            'freeze':list_data.freeze_status,
            'ac':list_data.ac_status,
            'fan':list_data.fan_status,
            'wifiName':list_data.wifi_name,
            

        }
        return JsonResponse(p)
    
    except Exception as e:
        print(e)




@login_required(login_url='login')
@csrf_exempt
def applianceStatus(request):

    if request.method == 'POST':
        list_data = AppliancesList.objects.get(i_name=request.user)

        # Bulb
        bulb1_status_update = request.POST['statuslight1']
        bulb2_status_update = request.POST['statuslight2']
        bulb3_status_update = request.POST['statuslight3']
        bulb4_status_update = request.POST['statuslight4']
        # Socket
        socket1_status_update = request.POST['statussocket1']
        socket2_status_update = request.POST['statussocket2']
        socket3_status_update = request.POST['statussocket3']
        socket4_status_update = request.POST['statussocket4']
        # Heavy Appliances
        cooler_status_update = request.POST['statuscooler']
        freeze_status_update = request.POST['statusfreeze']
        ac_status_update = request.POST['statusac']
        slider_status_update = request.POST['statusslider']


        # Bulb
        list_data.bulb1_status=bulb1_status_update
        list_data.bulb2_status=bulb2_status_update
        list_data.bulb3_status=bulb3_status_update
        list_data.bulb4_status=bulb4_status_update

        # Socket
        list_data.switch1_status=socket1_status_update
        list_data.switch2_status=socket2_status_update
        list_data.switch3_status=socket3_status_update
        list_data.switch4_status=socket4_status_update
        # Heavy Appliances
        list_data.cooler_status=cooler_status_update
        list_data.freeze_status=freeze_status_update
        list_data.ac_status=ac_status_update
        list_data.fan_status = slider_status_update

        list_data.save()
        device_mac = list_data.device_name
        sid =  list_data.id
        aws_id = str(sid)
        table.update_item(
            Key={
                'id': aws_id,
            },
            UpdateExpression="SET bulb1= :h,bulb2= :j,bulb3= :k,bulb4= :l,switch1= :m",
            ExpressionAttributeValues={
                ':h' : bulb1_status_update,
                ':j' : bulb2_status_update,
                ':k' : bulb3_status_update,
                ':l' : bulb4_status_update,
                ':m' : socket1_status_update,

            }
        )

    return JsonResponse({'status': 'Todo added!'})





# Save Edited Info of User
@login_required(login_url='login')
@csrf_exempt
def saveInfo(request):
    if request.method == 'POST':

        list_data = AppliancesList.objects.get(i_name=request.user)
        WIFINAME = request.POST['Name']
        # print(WIFINAME)
        WIFIPASSWORD = request.POST['Pass']
        EMAIL = request.POST['Email']
        list_data.wifi_name = WIFINAME
        list_data.wifi_password = WIFIPASSWORD
        list_data.emailId = EMAIL
        list_data.save()
        success = "Data Updated Successfully"

        #aws data
        device_mac = list_data.device_name
        #aws data
        sid =  list_data.id
        aws_id = str(sid)
        print(aws_id)
        table.update_item(
            Key={
                'id': aws_id,
            },
            UpdateExpression="SET wifi_name= :a,wifi_password= :c,emailId= :r",
            ExpressionAttributeValues={
                ':a': list_data.wifi_name,
                ':c': list_data.wifi_password,
                ':r': list_data.emailId,
            },
        )



    return HttpResponse(success)



